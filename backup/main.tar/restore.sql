--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.5 (Ubuntu 12.5-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.5 (Ubuntu 12.5-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE coursework;
--
-- Name: coursework; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE coursework WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE coursework OWNER TO postgres;

\connect coursework

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: generatedate(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generatedate() RETURNS date
    LANGUAGE plpgsql
    AS $$ declare outputDate date; begin select date (timestamp '2000-01-01' + random() * (timestamp '2020-12-31' - timestamp '2000-01-01')) into outputDate; return outputDate; end; $$;


ALTER FUNCTION public.generatedate() OWNER TO postgres;

--
-- Name: generateint(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generateint(max integer) RETURNS text
    LANGUAGE plpgsql
    AS $$ declare outputInt int; begin select trunc(random() * max + 1) into outputInt; return outputInt; end; $$;


ALTER FUNCTION public.generateint(max integer) OWNER TO postgres;

--
-- Name: generatestring(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generatestring(length integer) RETURNS text
    LANGUAGE plpgsql
    AS $$ declare outputString text; begin select string_agg(chr(trunc(97 + random()*25)::int), '') from generate_series(1, length) into outputString; return outputString; end; $$;


ALTER FUNCTION public.generatestring(length integer) OWNER TO postgres;

--
-- Name: getrandomrow(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getrandomrow(table_name text) RETURNS text
    LANGUAGE plpgsql
    AS $$ declare output int; begin EXECUTE format('select id from "%s" ORDER BY random() LIMIT 1', table_name) into output; return output; end; $$;


ALTER FUNCTION public.getrandomrow(table_name text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Category" (
    id integer NOT NULL,
    name character varying,
    type character varying
);


ALTER TABLE public."Category" OWNER TO postgres;

--
-- Name: Category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Category_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Category_id_seq" OWNER TO postgres;

--
-- Name: Category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Category_id_seq" OWNED BY public."Category".id;


--
-- Name: Client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Client" (
    id integer NOT NULL,
    name character varying,
    birthday_date date,
    email character varying
);


ALTER TABLE public."Client" OWNER TO postgres;

--
-- Name: Client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Client_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Client_id_seq" OWNER TO postgres;

--
-- Name: Client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Client_id_seq" OWNED BY public."Client".id;


--
-- Name: Link_Product-Category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Link_Product-Category" (
    product_id integer,
    category_id integer
);


ALTER TABLE public."Link_Product-Category" OWNER TO postgres;

--
-- Name: Link_Product-Order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Link_Product-Order" (
    product_id integer,
    order_id integer
);


ALTER TABLE public."Link_Product-Order" OWNER TO postgres;

--
-- Name: Order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Order" (
    id integer NOT NULL,
    transaction_date date,
    taxes_sum numeric,
    client_id integer
);


ALTER TABLE public."Order" OWNER TO postgres;

--
-- Name: Order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Order_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Order_id_seq" OWNER TO postgres;

--
-- Name: Order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Order_id_seq" OWNED BY public."Order".id;


--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    id integer NOT NULL,
    name character varying,
    brand character varying,
    manufacturer character varying,
    manufacture_date date,
    cost numeric
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: Product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Product_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Product_id_seq" OWNER TO postgres;

--
-- Name: Product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Product_id_seq" OWNED BY public."Product".id;


--
-- Name: Category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Category" ALTER COLUMN id SET DEFAULT nextval('public."Category_id_seq"'::regclass);


--
-- Name: Client id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client" ALTER COLUMN id SET DEFAULT nextval('public."Client_id_seq"'::regclass);


--
-- Name: Order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order" ALTER COLUMN id SET DEFAULT nextval('public."Order_id_seq"'::regclass);


--
-- Name: Product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product" ALTER COLUMN id SET DEFAULT nextval('public."Product_id_seq"'::regclass);


--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Category" (id, name, type) FROM stdin;
\.
COPY public."Category" (id, name, type) FROM '$$PATH$$/3016.dat';

--
-- Data for Name: Client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Client" (id, name, birthday_date, email) FROM stdin;
\.
COPY public."Client" (id, name, birthday_date, email) FROM '$$PATH$$/3014.dat';

--
-- Data for Name: Link_Product-Category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Link_Product-Category" (product_id, category_id) FROM stdin;
\.
COPY public."Link_Product-Category" (product_id, category_id) FROM '$$PATH$$/3019.dat';

--
-- Data for Name: Link_Product-Order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Link_Product-Order" (product_id, order_id) FROM stdin;
\.
COPY public."Link_Product-Order" (product_id, order_id) FROM '$$PATH$$/3022.dat';

--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Order" (id, transaction_date, taxes_sum, client_id) FROM stdin;
\.
COPY public."Order" (id, transaction_date, taxes_sum, client_id) FROM '$$PATH$$/3021.dat';

--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (id, name, brand, manufacturer, manufacture_date, cost) FROM stdin;
\.
COPY public."Product" (id, name, brand, manufacturer, manufacture_date, cost) FROM '$$PATH$$/3018.dat';

--
-- Name: Category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Category_id_seq"', 2029, true);


--
-- Name: Client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Client_id_seq"', 301, true);


--
-- Name: Order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Order_id_seq"', 1500, true);


--
-- Name: Product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Product_id_seq"', 988, true);


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (id);


--
-- Name: Client Client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Client"
    ADD CONSTRAINT "Client_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: Link_Product-Category Link_Product-Category_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Link_Product-Category"
    ADD CONSTRAINT "Link_Product-Category_category_id_fkey" FOREIGN KEY (category_id) REFERENCES public."Category"(id) ON DELETE CASCADE;


--
-- Name: Link_Product-Category Link_Product-Category_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Link_Product-Category"
    ADD CONSTRAINT "Link_Product-Category_product_id_fkey" FOREIGN KEY (product_id) REFERENCES public."Product"(id) ON DELETE CASCADE;


--
-- Name: Link_Product-Order Link_Product-Order_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Link_Product-Order"
    ADD CONSTRAINT "Link_Product-Order_order_id_fkey" FOREIGN KEY (order_id) REFERENCES public."Order"(id) ON DELETE CASCADE;


--
-- Name: Link_Product-Order Link_Product-Order_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Link_Product-Order"
    ADD CONSTRAINT "Link_Product-Order_product_id_fkey" FOREIGN KEY (product_id) REFERENCES public."Product"(id) ON DELETE CASCADE;


--
-- Name: Order Order_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_client_id_fkey" FOREIGN KEY (client_id) REFERENCES public."Client"(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

